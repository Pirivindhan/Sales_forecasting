"""Train and compare a previous-period baseline, Linear Regression, and Random Forest."""

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from src.data_preprocessing import PROJECT_ROOT
from src.exploratory_analysis import save_actual_vs_predicted


MODELS_DIR = PROJECT_ROOT / "models"
REPORTS_DIR = PROJECT_ROOT / "reports"
LAG_PERIODS = (1, 7, 14)
ROLLING_WINDOW = 7
FEATURE_COLUMNS = [
    "month",
    "day_of_week",
    "day_of_month",
    "year",
    "elapsed_days",
    "lag_1",
    "lag_7",
    "lag_14",
    "rolling_mean_7",
]


def _features_for_date(target_date, prior_sales, origin_date):
    """Build features for a date from calendar data and sales strictly before it."""
    if len(prior_sales) < max(LAG_PERIODS):
        raise ValueError("Not enough historical sales to construct the required lag features.")
    return {
        "month": target_date.month,
        "day_of_week": target_date.dayofweek,
        "day_of_month": target_date.day,
        "year": target_date.year,
        "elapsed_days": (target_date - origin_date).days,
        "lag_1": float(prior_sales[-1]),
        "lag_7": float(prior_sales[-7]),
        "lag_14": float(prior_sales[-14]),
        "rolling_mean_7": float(np.mean(prior_sales[-ROLLING_WINDOW:])),
    }


def create_supervised_data(daily_series):
    """Create one row per forecast date using only earlier observed target values."""
    series = daily_series.astype(float).sort_index()
    if len(series) < 30:
        raise ValueError(
            f"At least 30 daily periods are needed for the 14-day lags and a chronological "
            f"test (found {len(series)}). Add more historical data."
        )
    origin = series.index[0]
    rows = []
    for position in range(max(LAG_PERIODS), len(series)):
        date = series.index[position]
        values = _features_for_date(date, series.iloc[:position].tolist(), origin)
        values["target"] = float(series.iloc[position])
        values["date"] = date
        rows.append(values)
    supervised = pd.DataFrame(rows).set_index("date")
    return supervised[FEATURE_COLUMNS], supervised["target"]


def _metrics(actual, predicted):
    return {
        "MAE": float(mean_absolute_error(actual, predicted)),
        "RMSE": float(np.sqrt(mean_squared_error(actual, predicted))),
        "R2": float(r2_score(actual, predicted)) if len(actual) >= 2 else np.nan,
    }


def train_and_evaluate(daily_series, model_path=None, comparison_path=None):
    """Evaluate candidates on the same final chronological period, then save the winner."""
    features, target = create_supervised_data(daily_series)
    test_count = max(1, int(np.ceil(len(target) * 0.2)))
    split = len(target) - test_count
    if split < 2:
        raise ValueError(
            "There are too few feature rows for a chronological training and test split. "
            "Provide a longer date history."
        )

    x_train, x_test = features.iloc[:split], features.iloc[split:]
    y_train, y_test = target.iloc[:split], target.iloc[split:]
    candidates = {
        "Previous-day baseline": None,
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(
            n_estimators=200, random_state=42, min_samples_leaf=2, n_jobs=-1
        ),
    }
    rows = []
    test_predictions = {}
    for name, estimator in candidates.items():
        if estimator is None:
            # The baseline predicts the most recently known sales value.
            predictions = x_test["lag_1"].to_numpy()
        else:
            estimator.fit(x_train, y_train)
            predictions = estimator.predict(x_test)
        test_predictions[name] = pd.Series(predictions, index=y_test.index, name=name)
        rows.append({"Model": name, **_metrics(y_test, predictions)})

    comparison = pd.DataFrame(rows).sort_values("MAE").reset_index(drop=True)
    comparison_file = Path(comparison_path) if comparison_path else REPORTS_DIR / "model_comparison.csv"
    comparison_file.parent.mkdir(parents=True, exist_ok=True)
    comparison.to_csv(comparison_file, index=False)

    best_name = comparison.loc[0, "Model"]
    if best_name == "Previous-day baseline":
        best_estimator = None
    else:
        best_estimator = candidates[best_name]
        best_estimator.fit(features, target)

    bundle = {
        "model_name": best_name,
        "estimator": best_estimator,
        "feature_columns": FEATURE_COLUMNS,
        "lag_periods": list(LAG_PERIODS),
        "rolling_window": ROLLING_WINDOW,
        "frequency": "daily",
        "last_date": daily_series.index[-1],
        "history": daily_series.astype(float).tail(max(LAG_PERIODS)).tolist(),
        "origin_date": daily_series.index[0],
        "training_periods": len(daily_series),
    }
    model_file = Path(model_path) if model_path else MODELS_DIR / "sales_forecasting_model.joblib"
    model_file.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, model_file)

    best_prediction = test_predictions[best_name]
    save_actual_vs_predicted(y_test, best_prediction)
    print(f"\nChronological test results (same {len(y_test)} dates for each model):")
    print(comparison.to_string(index=False, float_format=lambda value: f"{value:,.3f}"))
    print(f"Best model by test MAE: {best_name}")
    print("The saved model was refit using all historical supervised rows.")
    print(f"Saved comparison: {comparison_file.relative_to(PROJECT_ROOT)}")
    print(f"Saved model: {model_file.relative_to(PROJECT_ROOT)}")

    return {
        "comparison": comparison,
        "best_model_name": best_name,
        "model_path": model_file,
        "comparison_path": comparison_file,
        "test_actual": y_test,
        "test_predictions": best_prediction,
    }
