"""Enhanced training with more features and optimized models for Ryzen 3."""

from pathlib import Path
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import Ridge, Lasso
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

from src.data_preprocessing import PROJECT_ROOT

warnings.filterwarnings('ignore')

MODELS_DIR = PROJECT_ROOT / "models"
REPORTS_DIR = PROJECT_ROOT / "reports"
LAG_PERIODS = (1, 7, 14, 21, 28)  # Extended lags for more patterns
ROLLING_WINDOWS = [7, 14, 28]  # Multiple rolling windows


def _enhanced_features_for_date(target_date, prior_sales, origin_date):
    """Build enhanced features including seasonality and advanced statistics."""
    if len(prior_sales) < max(LAG_PERIODS):
        raise ValueError("Not enough historical sales to construct the required lag features.")

    # Basic calendar features
    features = {
        "month": target_date.month,
        "day_of_week": target_date.dayofweek,
        "day_of_month": target_date.day,
        "quarter": target_date.quarter,
        "year": target_date.year,
        "elapsed_days": (target_date - origin_date).days,
        "week_of_year": target_date.isocalendar()[1],
        "is_weekend": int(target_date.dayofweek >= 5),
        "is_month_start": int(target_date.is_month_start),
        "is_month_end": int(target_date.is_month_end),
        "is_quarter_start": int(target_date.is_quarter_start),
        "is_quarter_end": int(target_date.is_quarter_end),
    }

    # Cyclical encoding for month and day_of_week (captures circular nature)
    features["month_sin"] = np.sin(2 * np.pi * target_date.month / 12)
    features["month_cos"] = np.cos(2 * np.pi * target_date.month / 12)
    features["dow_sin"] = np.sin(2 * np.pi * target_date.dayofweek / 7)
    features["dow_cos"] = np.cos(2 * np.pi * target_date.dayofweek / 7)

    # Lag features
    for lag in LAG_PERIODS:
        features[f"lag_{lag}"] = float(prior_sales[-lag])

    # Rolling statistics for multiple windows
    for window in ROLLING_WINDOWS:
        if len(prior_sales) >= window:
            window_values = prior_sales[-window:]
            features[f"rolling_mean_{window}"] = float(np.mean(window_values))
            features[f"rolling_std_{window}"] = float(np.std(window_values))
            features[f"rolling_min_{window}"] = float(np.min(window_values))
            features[f"rolling_max_{window}"] = float(np.max(window_values))

    # Trend features (difference between recent and older averages)
    if len(prior_sales) >= 28:
        recent_avg = np.mean(prior_sales[-7:])
        older_avg = np.mean(prior_sales[-28:-7])
        features["trend_7_vs_28"] = float(recent_avg - older_avg)
        features["trend_ratio_7_vs_28"] = float(recent_avg / (older_avg + 1e-6))

    # Momentum features
    if len(prior_sales) >= 7:
        features["momentum_7"] = float(prior_sales[-1] - prior_sales[-7])
    if len(prior_sales) >= 14:
        features["momentum_14"] = float(prior_sales[-1] - prior_sales[-14])

    return features


def create_enhanced_supervised_data(daily_series):
    """Create supervised data with enhanced features."""
    series = daily_series.astype(float).sort_index()
    if len(series) < 35:
        raise ValueError(
            f"At least 35 daily periods are needed for enhanced features "
            f"(found {len(series)}). Add more historical data."
        )
    origin = series.index[0]
    rows = []

    for position in range(max(LAG_PERIODS), len(series)):
        date = series.index[position]
        values = _enhanced_features_for_date(date, series.iloc[:position].tolist(), origin)
        values["target"] = float(series.iloc[position])
        values["date"] = date
        rows.append(values)

    supervised = pd.DataFrame(rows).set_index("date")
    feature_columns = [col for col in supervised.columns if col != "target"]
    return supervised[feature_columns], supervised["target"], feature_columns


def _metrics(actual, predicted):
    """Calculate evaluation metrics."""
    return {
        "MAE": float(mean_absolute_error(actual, predicted)),
        "RMSE": float(np.sqrt(mean_squared_error(actual, predicted))),
        "R2": float(r2_score(actual, predicted)) if len(actual) >= 2 else np.nan,
        "MAPE": float(np.mean(np.abs((actual - predicted) / (actual + 1e-6))) * 100),
    }


def train_and_evaluate_enhanced(daily_series, model_path=None, comparison_path=None):
    """Train enhanced models optimized for Ryzen 3 performance."""
    print("\n" + "="*70)
    print("ENHANCED MODEL TRAINING - Optimized for Ryzen 3")
    print("="*70)

    features, target, feature_columns = create_enhanced_supervised_data(daily_series)
    print(f"\nDataset: {len(target)} supervised samples with {len(feature_columns)} features")

    # Feature scaling for better performance
    scaler = StandardScaler()
    features_scaled = pd.DataFrame(
        scaler.fit_transform(features),
        index=features.index,
        columns=features.columns
    )

    # Chronological split
    test_count = max(1, int(np.ceil(len(target) * 0.2)))
    split = len(target) - test_count

    x_train, x_test = features_scaled.iloc[:split], features_scaled.iloc[split:]
    y_train, y_test = target.iloc[:split], target.iloc[split:]

    print(f"Training samples: {len(x_train)} | Test samples: {len(x_test)}")
    print("\nTraining models (Ryzen 3 optimized - limited complexity)...")

    # Models optimized for Ryzen 3 (4 cores, limited memory)
    candidates = {
        "Previous-day baseline": None,
        "Ridge Regression": Ridge(alpha=10.0),
        "Lasso Regression": Lasso(alpha=5.0, max_iter=2000),
        "Random Forest (Optimized)": RandomForestRegressor(
            n_estimators=100,  # Reduced from 200 for Ryzen 3
            max_depth=15,  # Limit depth to prevent overfitting
            min_samples_leaf=3,
            min_samples_split=5,
            random_state=42,
            n_jobs=3  # Use 3 cores, leave 1 for OS
        ),
        "Gradient Boosting": GradientBoostingRegressor(
            n_estimators=100,  # Lightweight
            learning_rate=0.1,
            max_depth=5,  # Shallow trees
            min_samples_leaf=3,
            random_state=42,
            subsample=0.8
        ),
    }

    rows = []
    test_predictions = {}
    feature_importances = {}

    for name, estimator in candidates.items():
        print(f"  > Training {name}...", end=" ")

        if estimator is None:
            # Baseline: use lag_1 from UNSCALED features
            predictions = features.iloc[split:]["lag_1"].to_numpy()
        else:
            estimator.fit(x_train, y_train)
            predictions = estimator.predict(x_test)

            # Extract feature importance for tree-based models
            if hasattr(estimator, 'feature_importances_'):
                feature_importances[name] = dict(
                    zip(feature_columns, estimator.feature_importances_)
                )

        test_predictions[name] = pd.Series(predictions, index=y_test.index, name=name)
        metrics = _metrics(y_test, predictions)
        rows.append({"Model": name, **metrics})
        print(f"MAE: {metrics['MAE']:,.0f}")

    # Create comparison table
    comparison = pd.DataFrame(rows).sort_values("MAE").reset_index(drop=True)
    comparison_file = Path(comparison_path) if comparison_path else REPORTS_DIR / "model_comparison_enhanced.csv"
    comparison_file.parent.mkdir(parents=True, exist_ok=True)
    comparison.to_csv(comparison_file, index=False)

    # Select and refit best model
    best_name = comparison.loc[0, "Model"]
    print(f"\n{'='*70}")
    print(f"BEST MODEL: {best_name}")
    print(f"{'='*70}")

    if best_name == "Previous-day baseline":
        best_estimator = None
        best_scaler = None
    else:
        best_estimator = candidates[best_name]
        best_estimator.fit(features_scaled, target)
        best_scaler = scaler

        # Show feature importance
        if best_name in feature_importances:
            print("\nTop 10 Most Important Features:")
            sorted_features = sorted(
                feature_importances[best_name].items(),
                key=lambda x: x[1],
                reverse=True
            )[:10]
            for feat, importance in sorted_features:
                print(f"  {feat:30s}: {importance:.4f}")

    # Save enhanced model bundle
    bundle = {
        "model_name": best_name,
        "estimator": best_estimator,
        "scaler": best_scaler,
        "feature_columns": feature_columns,
        "lag_periods": list(LAG_PERIODS),
        "rolling_windows": ROLLING_WINDOWS,
        "frequency": "daily",
        "last_date": daily_series.index[-1],
        "history": daily_series.astype(float).tail(max(LAG_PERIODS)).tolist(),
        "origin_date": daily_series.index[0],
        "training_periods": len(daily_series),
        "enhanced": True,  # Flag for prediction script
    }

    model_file = Path(model_path) if model_path else MODELS_DIR / "sales_forecasting_model_enhanced.joblib"
    model_file.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, model_file)

    # Display results
    print(f"\n{'='*70}")
    print("MODEL COMPARISON (All models on same test period)")
    print(f"{'='*70}")
    print(comparison.to_string(index=False, float_format=lambda x: f"{x:,.2f}"))
    print(f"\n[OK] Saved comparison: {comparison_file.relative_to(PROJECT_ROOT)}")
    print(f"[OK] Saved enhanced model: {model_file.relative_to(PROJECT_ROOT)}")

    return {
        "comparison": comparison,
        "best_model_name": best_name,
        "model_path": model_file,
        "comparison_path": comparison_file,
        "test_actual": y_test,
        "test_predictions": test_predictions[best_name],
        "feature_columns": feature_columns,
        "all_predictions": test_predictions,
    }
