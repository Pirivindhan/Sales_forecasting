"""Batch train the forecasting model across all retail datasets in data/."""

import shutil
import sys
import time
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
from src.data_preprocessing import load_and_prepare_data, save_cleaned_data
from src.train_model_perfect import train_and_evaluate_perfect
from src.predict_sales_perfect import forecast_future_perfect

DATA_DIR = PROJECT_ROOT / "data"
REPORTS_DIR = PROJECT_ROOT / "reports"
MODELS_DIR = PROJECT_ROOT / "models"
REPORTS_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)

datasets = sorted(DATA_DIR.glob("*.csv"))
all_results = []

print("=" * 75)
print("  MULTI-DATASET ADVANCED MODEL TRAINING PIPELINE")
print(f"  Discovered {len(datasets)} enterprise sales datasets in data/")
print("=" * 75)

for i, dataset_path in enumerate(datasets, 1):
    name = dataset_path.name
    slug = dataset_path.stem

    print(f"\n{'=' * 75}")
    print(f"  [{i}/{len(datasets)}] Processing & Training on: {name}")
    print(f"{'=' * 75}")

    start = time.time()
    try:
        clean_rows, daily_sales, metadata = load_and_prepare_data(dataset_path)

        # Train with noise-aware hybrid ensemble & multi-estimator gradient boosting
        training = train_and_evaluate_perfect(daily_sales)

        # Save dataset-specific model bundle
        custom_model_path = MODELS_DIR / f"model_{slug}.joblib"
        shutil.copy2(training["model_path"], custom_model_path)

        # 30-day recursive future forecast
        forecast = forecast_future_perfect(training["model_path"], periods=30)
        forecast_file = REPORTS_DIR / f"forecast_{slug}.csv"
        forecast.to_csv(forecast_file, index=False)

        # Save dataset comparison table
        comparison_file = REPORTS_DIR / f"comparison_{slug}.csv"
        training["comparison"].to_csv(comparison_file, index=False)

        elapsed = time.time() - start
        best = training["comparison"].iloc[0]

        result = {
            "Dataset": name,
            "Total Records": f"{metadata['original_rows']:,}",
            "Daily Time-Series Days": f"{metadata['calendar_days']:,}",
            "Date Range": f"{daily_sales.index.min().date()} to {daily_sales.index.max().date()}",
            "Best Architecture": training["best_model_name"],
            "MAE": f"{best['MAE']:,.2f}",
            "RMSE": f"{best['RMSE']:,.2f}",
            "R2": f"{best['R2']:+.4f}",
            "Avg Daily Forecast": f"{forecast['forecast_sales'].mean():,.2f}",
            "Training Time": f"{elapsed:.1f}s",
            "Model Saved": custom_model_path.name,
            "Status": "COMPLETED",
        }
        all_results.append(result)

        print(f"\n  [SUCCESS] {name}")
        print(f"  • Best Model: {training['best_model_name']}")
        print(f"  • Holdout MAE: {best['MAE']:,.2f}")
        print(f"  • 30-Day Avg Forecast: {forecast['forecast_sales'].mean():,.2f}")
        print(f"  • Saved: {custom_model_path.name}")

    except Exception as exc:
        elapsed = time.time() - start
        print(f"\n  [ERROR] {name}: {exc}")
        all_results.append({
            "Dataset": name,
            "Total Records": "-",
            "Daily Time-Series Days": "-",
            "Date Range": "-",
            "Best Architecture": "-",
            "MAE": "-",
            "RMSE": "-",
            "R2": "-",
            "Avg Daily Forecast": "-",
            "Training Time": f"{elapsed:.1f}s",
            "Model Saved": "-",
            "Status": f"FAILED: {exc}",
        })

# Save and display master report
results_df = pd.DataFrame(all_results)
report_path = REPORTS_DIR / "batch_training_report.csv"
results_df.to_csv(report_path, index=False)

print(f"\n\n{'=' * 75}")
print("  MULTI-DATASET TRAINING COMPLETE - ALL MODELS TRAINED")
print(f"{'=' * 75}\n")
print(results_df.to_string(index=False))
print(f"\n\nMaster Report Saved: {report_path}")
