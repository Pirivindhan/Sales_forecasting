"""Generate forecasts using the enhanced model with advanced features."""

import argparse
from pathlib import Path

import joblib
import pandas as pd
import numpy as np

from src.data_preprocessing import PROJECT_ROOT


def _enhanced_features_for_date(target_date, prior_sales, origin_date, lag_periods, rolling_windows):
    """Build enhanced features - must match training features exactly."""
    # Basic calendar features
    features = {
        "month": target_date.month,
        "day_of_week": target_date.dayofweek,
        "day_of_month": target_date.day,
        "quarter": target_date.quarter,
        "year": target_date.year,
        "elapsed_days": (target_date - origin_date).days,
        "week_of_year": target_date.isocalendar()[1],
        "is_weekend": int(target_date.dayofweek >= 5),
        "is_month_start": int(target_date.is_month_start),
        "is_month_end": int(target_date.is_month_end),
        "is_quarter_start": int(target_date.is_quarter_start),
        "is_quarter_end": int(target_date.is_quarter_end),
    }

    # Cyclical encoding
    features["month_sin"] = np.sin(2 * np.pi * target_date.month / 12)
    features["month_cos"] = np.cos(2 * np.pi * target_date.month / 12)
    features["dow_sin"] = np.sin(2 * np.pi * target_date.dayofweek / 7)
    features["dow_cos"] = np.cos(2 * np.pi * target_date.dayofweek / 7)

    # Lag features
    for lag in lag_periods:
        features[f"lag_{lag}"] = float(prior_sales[-lag])

    # Rolling statistics
    for window in rolling_windows:
        if len(prior_sales) >= window:
            window_values = prior_sales[-window:]
            features[f"rolling_mean_{window}"] = float(np.mean(window_values))
            features[f"rolling_std_{window}"] = float(np.std(window_values))
            features[f"rolling_min_{window}"] = float(np.min(window_values))
            features[f"rolling_max_{window}"] = float(np.max(window_values))

    # Trend features
    if len(prior_sales) >= 28:
        recent_avg = np.mean(prior_sales[-7:])
        older_avg = np.mean(prior_sales[-28:-7])
        features["trend_7_vs_28"] = float(recent_avg - older_avg)
        features["trend_ratio_7_vs_28"] = float(recent_avg / (older_avg + 1e-6))

    # Momentum features
    if len(prior_sales) >= 7:
        features["momentum_7"] = float(prior_sales[-1] - prior_sales[-7])
    if len(prior_sales) >= 14:
        features["momentum_14"] = float(prior_sales[-1] - prior_sales[-14])

    return features


def forecast_future_enhanced(model_path=None, periods=30, output_path=None):
    """Generate future forecasts using the enhanced model."""
    model_file = Path(model_path) if model_path else PROJECT_ROOT / "models" / "sales_forecasting_model_enhanced.joblib"

    if not model_file.is_file():
        raise FileNotFoundError(
            f"Enhanced model not found: {model_file}. "
            "Run the enhanced training script first."
        )

    if periods < 1:
        raise ValueError("Forecast periods must be at least 1.")

    print(f"\n{'='*70}")
    print(f"GENERATING {periods}-DAY FORECAST (Enhanced Model)")
    print(f"{'='*70}")

    bundle = joblib.load(model_file)
    history = list(bundle["history"])
    last_date = pd.Timestamp(bundle["last_date"])
    origin = pd.Timestamp(bundle["origin_date"])
    estimator = bundle["estimator"]
    scaler = bundle.get("scaler")
    model_name = bundle["model_name"]
    feature_columns = bundle["feature_columns"]
    lag_periods = bundle.get("lag_periods", [1, 7, 14, 21, 28])
    rolling_windows = bundle.get("rolling_windows", [7, 14, 28])

    print(f"Model: {model_name}")
    print(f"Last training date: {last_date.date()}")
    print(f"Forecast start: {(last_date + pd.Timedelta(days=1)).date()}")
    print(f"Forecast end: {(last_date + pd.Timedelta(days=periods)).date()}")

    records = []

    for offset in range(1, periods + 1):
        forecast_date = last_date + pd.Timedelta(days=offset)
        feature_values = _enhanced_features_for_date(
            forecast_date, history, origin, lag_periods, rolling_windows
        )

        if estimator is None:
            # Baseline: use the most recent value
            prediction = history[-1]
        else:
            # Create feature row
            row = pd.DataFrame([feature_values], columns=feature_columns)

            # Scale if scaler exists
            if scaler is not None:
                row_scaled = scaler.transform(row)
                prediction = float(estimator.predict(row_scaled)[0])
            else:
                prediction = float(estimator.predict(row)[0])

        # Clip negative predictions
        prediction = max(0.0, float(prediction))

        records.append({
            "date": forecast_date,
            "forecast_sales": prediction,
            "forecast_type": "genuine_future_forecast",
            "model": model_name,
        })

        history.append(prediction)

        if offset % 10 == 0 or offset == periods:
            print(f"  > Generated {offset}/{periods} forecasts...")

    forecasts = pd.DataFrame(records)
    destination = Path(output_path) if output_path else PROJECT_ROOT / "reports" / "future_forecast_enhanced.csv"
    destination.parent.mkdir(parents=True, exist_ok=True)
    forecasts.to_csv(destination, index=False, date_format="%Y-%m-%d")

    # Summary statistics
    avg_forecast = forecasts["forecast_sales"].mean()
    min_forecast = forecasts["forecast_sales"].min()
    max_forecast = forecasts["forecast_sales"].max()

    print(f"\n{'='*70}")
    print("FORECAST SUMMARY")
    print(f"{'='*70}")
    print(f"Average daily sales: {avg_forecast:,.2f}")
    print(f"Minimum daily sales: {min_forecast:,.2f}")
    print(f"Maximum daily sales: {max_forecast:,.2f}")
    print(f"Total forecast period: {forecasts['forecast_sales'].sum():,.2f}")
    print(f"\n[OK] Saved forecast: {destination.relative_to(PROJECT_ROOT)}")

    return forecasts


def main():
    parser = argparse.ArgumentParser(
        description="Forecast future sales using the enhanced model."
    )
    parser.add_argument(
        "--periods",
        type=int,
        default=30,
        help="Number of future days to forecast (default: 30)."
    )
    parser.add_argument(
        "--model",
        default=None,
        help="Model path (default: models/sales_forecasting_model_enhanced.joblib)."
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Output CSV path (default: reports/future_forecast_enhanced.csv)."
    )
    args = parser.parse_args()
    forecast_future_enhanced(args.model, args.periods, args.output)


if __name__ == "__main__":
    main()
