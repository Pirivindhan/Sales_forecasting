"""Create readable sales charts and save them as high-resolution PNG files."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from src.data_preprocessing import PROJECT_ROOT


GRAPHS_DIR = PROJECT_ROOT / "graphs"


def generate_eda_graphs(daily_series, cleaned_rows, category_column=None):
    """Generate historical trend, monthly totals, distribution, and optional category plots."""
    GRAPHS_DIR.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")
    outputs = []

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(daily_series.index, daily_series.values, color="#2463a6", linewidth=1)
    ax.set(title="Historical Daily Sales", xlabel="Date", ylabel="Sales")
    fig.tight_layout()
    path = GRAPHS_DIR / "historical_sales_trend.png"
    fig.savefig(path, dpi=300)
    plt.close(fig)
    outputs.append(path)

    monthly = daily_series.resample("MS").sum()
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(monthly.index, monthly.values, marker="o", markersize=3, color="#27866b")
    ax.set(title="Monthly Sales Totals", xlabel="Month", ylabel="Sales")
    fig.tight_layout()
    path = GRAPHS_DIR / "monthly_sales_analysis.png"
    fig.savefig(path, dpi=300)
    plt.close(fig)
    outputs.append(path)

    fig, ax = plt.subplots(figsize=(9, 5))
    sns.histplot(daily_series.values, bins=30, kde=True, ax=ax, color="#d17a22")
    ax.set(title="Distribution of Daily Sales", xlabel="Daily sales", ylabel="Number of days")
    fig.tight_layout()
    path = GRAPHS_DIR / "sales_distribution.png"
    fig.savefig(path, dpi=300)
    plt.close(fig)
    outputs.append(path)

    if category_column and category_column in cleaned_rows.columns:
        category_sales = (
            cleaned_rows.groupby(category_column, dropna=False)["sales"]
            .sum()
            .sort_values(ascending=False)
            .head(15)
            .sort_values()
        )
        if not category_sales.empty:
            fig, ax = plt.subplots(figsize=(10, max(5, len(category_sales) * 0.35)))
            category_sales.plot(kind="barh", ax=ax, color="#8055a5")
            ax.set(title="Sales by Category (Top 15)", xlabel="Sales", ylabel="Category")
            fig.tight_layout()
            path = GRAPHS_DIR / "category_sales_comparison.png"
            fig.savefig(path, dpi=300)
            plt.close(fig)
            outputs.append(path)

    for graph in outputs:
        print(f"Saved graph: {graph.relative_to(PROJECT_ROOT)}")
    print(
        "EDA charts show the daily trend, monthly totals, and distribution of daily sales"
        + ("; category totals are also shown." if category_column else ".")
    )
    return outputs


def save_actual_vs_predicted(actual, predicted, output_path=None):
    """Plot chronological holdout predictions against actual sales."""
    destination = Path(output_path) if output_path else GRAPHS_DIR / "actual_vs_predicted.png"
    destination.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(actual.index, actual.values, label="Actual", color="#222222", linewidth=1.5)
    ax.plot(predicted.index, predicted.values, label="Predicted", color="#c84545", linewidth=1.5)
    ax.set(title="Actual vs Predicted Sales (Chronological Test Period)", xlabel="Date", ylabel="Sales")
    ax.legend()
    fig.tight_layout()
    fig.savefig(destination, dpi=300)
    plt.close(fig)
    print(f"Saved test-period comparison graph: {destination.relative_to(PROJECT_ROOT)}")
    return destination
