# Industry-Oriented Sales Forecasting

## Abstract

This project demonstrates a reproducible, local machine-learning workflow for retail demand forecasting. It reads historical transactions, validates dates and sales, aggregates transactions into a daily time series, explores sales patterns, compares a previous-day baseline with Linear Regression and Random Forest, and recursively forecasts future daily sales. The program reports measured holdout errors; it does not assume or promise that any model is accurate.

## Problem statement

Retail businesses need estimates of future demand to plan inventory, staffing, and purchasing. Transaction data can be irregular, contain invalid values, and exhibit calendar patterns. This project provides a beginner-friendly workflow that prepares historical data and evaluates candidate models on a later chronological period before forecasting beyond the observed dates.

## Aim and objectives

- Load and validate historical retail sales from a local CSV file.
- Report duplicate and invalid rows instead of silently ignoring data quality issues.
- Visualize historical, monthly, distribution, and optionally category-level sales.
- Create time and lag features without using future target values.
- Compare a simple baseline, Linear Regression, and Random Forest on the same chronological test dates.
- Save evaluation results, a reusable model bundle, and clearly labeled future forecasts.

## Technologies

Python 3, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn, and Joblib. All processing runs locally; there are no API keys or hosted services.

## Dataset

The preferred source is the [Kaggle Sales Forecasting dataset](https://www.kaggle.com/datasets/rohitsahoo/sales-forecasting). Download its CSV manually; this project does not download the dataset or require a Kaggle account/API key at runtime.

Place one input CSV in `data/`. The program recognizes common date names such as `Order Date`, `Invoice Date`, `transaction_date`, `timestamp`, and `date`, and sales names such as `Sales`, `Net Sales`, `Total Revenue`, `order_amount`, and `amount`. A CSV with common quantity and unit-price columns is also supported: it derives sales as quantity × price and says so in the console. Currency symbols, thousands separators, and accounting-style negative values are accepted in sales and price fields. The workspace-provided `customer_shopping_data.csv` is supported in the project root using its `invoice_date`, `quantity`, and `price` columns. For future datasets, prefer `data/`.

When multiple CSV files are in `data/`, keep only the intended input there or pass the dataset path on the command line. For non-standard headers, explicitly map the date and sales fields:

```powershell
python main.py --dataset "data\your_file.csv" --date-column "Event Time" --sales-column "Gross Amount"
```

This workflow is for transaction-level CSV data with a parseable date and non-negative daily sales totals. It does not automatically support every file format, schema, currency convention, or forecasting target; for example, Excel files, product-specific forecasts, and locale-specific decimal commas need conversion or additional configuration. Category fields are optional and are used only for the category chart.

## Folder structure

```text
Sales_Forecasting_Project/
├── data/                       # Put the input CSV here
├── graphs/                     # Generated high-resolution PNG charts
├── models/                     # Saved Joblib model and metadata
├── reports/                    # Cleaned data, comparison, future forecasts
├── src/
│   ├── data_preprocessing.py
│   ├── exploratory_analysis.py
│   ├── train_model.py
│   └── predict_sales.py
├── main.py
├── requirements.txt
├── README.md
├── .gitignore
└── .env.example
```

## Installation on Windows PowerShell

Open the project folder in VS Code, then run these commands in the integrated PowerShell terminal:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell blocks virtual-environment activation, use this only for the current terminal:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

In VS Code, open the Command Palette (`Ctrl+Shift+P`), choose **Python: Select Interpreter**, and select the interpreter under `.venv\Scripts\python.exe`.

## Execution

1. Put the downloaded retail CSV in `data\` (the supplied root-level CSV is automatically recognized if `data\` has no CSV). If needed, specify a file and column mapping with the command shown above.
2. Activate the `.venv` environment in the VS Code terminal.
3. Run the full workflow:

   ```powershell
   python main.py
   ```

4. To make a different number of future daily forecasts after training:

   ```powershell
   python -m src.predict_sales --periods 14
   ```

The prediction command needs the saved model created by `python main.py`. If no dataset is present, the program prints the location and required columns rather than fabricating data.

## Application UI

You can run the project as a browser-based application instead of only the terminal workflow:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

The app lets you upload a CSV, choose the date and sales columns, set the forecast horizon, and see the cleaned data, model comparison, and forecast results in a single interface.

## Methodology

### Data preprocessing

Column headers are standardized internally (for example, `Order Date` becomes `order_date`). The loader detects the date and sales fields, parses dates, converts sales to numbers, removes exact duplicate rows, and excludes rows with missing/unparseable dates or missing, non-numeric, non-finite, or negative sales. It reports counts and warns when more than 25% of rows are removed. When no direct sales field exists, a dataset containing `quantity` and `price` uses their product as sales.

Transactions are summed by date and sorted chronologically. The resulting daily calendar series fills days without recorded transactions with zero. This treats a missing transaction date as a zero-sales day; check that assumption against the source system before business use. Cleaned daily data is saved to `reports/cleaned_sales.csv`.

### Exploratory data analysis

- `historical_sales_trend.png`: daily sales over the observed date range.
- `monthly_sales_analysis.png`: monthly sums, useful for seeing longer-term changes and seasonality.
- `sales_distribution.png`: distribution of daily sales values.
- `actual_vs_predicted.png`: best model's predictions against actual values for the chronological holdout period only.
- `category_sales_comparison.png`: optional top category totals when a `category` column exists.

All charts are saved at 300 DPI in `graphs/`.

### Feature engineering and leakage prevention

The forecast step is one day. Features include month, day of week, day of month, year, elapsed days, 1/7/14-day sales lags, and a seven-day rolling mean. The rolling mean uses only the seven periods before the target date. Training features for a target date are constructed from earlier observations only. During future forecasting, each prediction is appended to history before the next date's lag and rolling features are built.

### Models

- **Previous-day baseline:** predicts the latest known sales value. During multi-day forecasting, it uses the preceding actual or forecast value.
- **Linear Regression:** provides a simple interpretable linear relationship between engineered features and sales.
- **Random Forest Regressor:** captures nonlinear patterns using an ensemble of decision trees. `random_state=42` makes its randomized fitting reproducible.

At least 30 daily periods are required for lag construction and a meaningful chronological split. Each candidate is evaluated on the same final 20% of supervised dates. The winning model is selected by lowest test-set MAE, then refit on all available supervised rows and saved. A baseline may win and is supported as a valid saved forecasting strategy.

### Evaluation metrics

- **MAE:** average absolute forecast error in the sales unit; lower is better.
- **RMSE:** square root of mean squared error; it emphasizes larger misses; lower is better.
- **R²:** variance explained relative to a constant-mean reference. It is only reported when at least two test observations exist; it can be negative and is not an accuracy percentage.

Actual values, model errors, and scores are calculated when you run the project. No results are asserted in advance. The comparison table is saved to `reports/model_comparison.csv`.

## Understanding outputs and results

`reports/future_forecast.csv` contains recursive predictions after the last observed date and labels them `genuine_future_forecast`. These are model-generated estimates, not actual sales or test-set predictions. `actual_vs_predicted.png` and `model_comparison.csv` refer to the historical holdout test period. Compare MAE/RMSE to the scale and variability of your sales before judging usefulness; a low score alone does not establish business value.

## Business applications

- Demand planning and replenishment discussions.
- Identifying broad trends or seasonal patterns for review.
- Comparing a basic benchmark with more complex models.
- Supporting inventory and staffing scenarios when combined with domain knowledge.

Forecasts are decision support, not automatic purchasing instructions.

## Limitations

- This is a demonstration model, not a production demand-planning service.
- Missing calendar dates are treated as zero-sales days.
- The daily model does not account for promotions, holidays, stock-outs, price changes, or external factors unless represented in the input (and no such variables are currently modeled).
- Recursive predictions can compound errors over longer horizons.
- A single chronological holdout can be sensitive to the chosen history and changing business conditions.
- The minimum history check is not a guarantee that the dataset is representative or the model is useful.
- Date strings with ambiguous numeric month/day order can be interpreted according to the data's apparent convention; verify parsed dates for your source.

## Future enhancements

- Add rolling-origin backtesting and prediction intervals.
- Include promotion, holiday, price, and inventory availability features.
- Support category/store-specific forecasts and compare daily versus monthly horizons.
- Add data-quality reports and a small dashboard for business users.
- Monitor forecast errors as new actual sales arrive.

## Conclusion

This project provides a complete, reproducible baseline workflow: validated data preparation, exploratory charts, leakage-conscious feature generation, chronological model evaluation, and recursive forecasts. Run it against the intended source data and use the generated metrics and plots—not assumed results—to decide whether further modeling work is justified.

## Internship submission checklist

Keep the source code and `README.md` in the submission. Include the generated model comparison CSV, cleaned data if permitted, forecast CSV, and the PNG graphs that demonstrate the analysis and holdout evaluation. Do not include `.venv` or large/private source datasets unless the submission rules explicitly require them; instead document the dataset source and schema.
