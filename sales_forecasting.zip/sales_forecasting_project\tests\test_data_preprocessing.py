import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from src.data_preprocessing import load_and_prepare_data
from src.train_model_perfect import _build_rich_features, train_and_evaluate_perfect
from src.predict_sales_perfect import forecast_future_perfect, _rebuild_feature_row


class LoadAndPrepareDataTests(unittest.TestCase):
    def _load_csv(self, frame, **kwargs):
        temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(temporary_directory.cleanup)
        path = Path(temporary_directory.name) / "sales.csv"
        frame.to_csv(path, index=False)
        return load_and_prepare_data(path, **kwargs)

    def test_recognizes_common_headers_and_currency_sales(self):
        source = pd.DataFrame(
            {
                "Transaction Date": [
                    "2024-01-01",
                    "2024-01-01",
                    "2024-01-02",
                    "2024-01-03",
                ],
                "Net Sales": ["$1,200.50", "2,000", "0", "(25.00)"],
            }
        )

        cleaned, daily, metadata = self._load_csv(source)

        self.assertEqual(metadata["date_column"], "transaction_date")
        self.assertEqual(metadata["sales_column"], "net_sales")
        self.assertEqual(metadata["invalid_rows_removed"], 1)
        self.assertEqual(len(cleaned), 3)
        self.assertEqual(daily.iloc[0], 3200.5)
        self.assertEqual(daily.iloc[1], 0.0)

    def test_derives_sales_from_quantity_and_unit_price_aliases(self):
        source = pd.DataFrame(
            {
                "Sale Date": ["2024-02-01", "2024-02-01"],
                "Qty": [3, 2],
                "Unit Price": ["$12.50", "4.50"],
            }
        )

        _, daily, metadata = self._load_csv(source)

        self.assertTrue(metadata["derived_sales"])
        self.assertEqual(daily.iloc[0], 46.5)

    def test_accepts_explicit_nonstandard_column_mapping(self):
        source = pd.DataFrame(
            {
                "Event Time": ["2024-03-01"],
                "Gross Amount": ["75.25"],
            }
        )

        _, daily, metadata = self._load_csv(
            source, date_column="Event Time", sales_column="Gross Amount"
        )

        self.assertEqual(metadata["date_column"], "event_time")
        self.assertEqual(metadata["sales_column"], "gross_amount")
        self.assertEqual(daily.iloc[0], 75.25)


class PerfectModelPipelineTests(unittest.TestCase):
    def setUp(self):
        # 100 days of synthetic daily sales
        dates = pd.date_range("2023-01-01", periods=100, freq="D")
        np.random.seed(42)
        sales = np.random.normal(300000, 50000, size=100).clip(min=10000)
        self.daily = pd.Series(sales, index=dates, name="sales")

    def test_build_rich_features(self):
        features, target, cols = _build_rich_features(self.daily)
        self.assertGreater(len(features), 30)
        self.assertEqual(len(features), len(target))
        self.assertIn("rmean_7", cols)
        self.assertIn("dow_sin", cols)
        self.assertIn("trend_7v28", cols)

    def test_train_and_forecast_end_to_end(self):
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        model_p = Path(temp_dir.name) / "test_model.joblib"
        comp_p = Path(temp_dir.name) / "test_comp.csv"
        fc_p = Path(temp_dir.name) / "test_fc.csv"

        results = train_and_evaluate_perfect(self.daily, model_path=model_p, comparison_path=comp_p)
        self.assertTrue(model_p.exists())
        self.assertTrue(comp_p.exists())
        self.assertIn("best_model_name", results)

        forecasts = forecast_future_perfect(model_path=model_p, periods=7, output_path=fc_p)
        self.assertEqual(len(forecasts), 7)
        self.assertTrue((forecasts["forecast_sales"] >= 0).all())


if __name__ == "__main__":
    unittest.main()
