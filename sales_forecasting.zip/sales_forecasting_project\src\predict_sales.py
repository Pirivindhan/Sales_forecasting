"""Generate recursive future daily forecasts from a saved model bundle."""

import argparse
from pathlib import Path

import joblib
import pandas as pd

from src.data_preprocessing import PROJECT_ROOT
from src.train_model import FEATURE_COLUMNS, _features_for_date


def forecast_future(model_path=None, periods=30, output_path=None):
    """Forecast multiple future dates, feeding each prediction into later lag features."""
    model_file = Path(model_path) if model_path else PROJECT_ROOT / "models" / "sales_forecasting_model.joblib"
    if not model_file.is_file():
        raise FileNotFoundError(
            f"Saved model not found: {model_file}. Run python main.py to train the model first."
        )
    if periods < 1:
        raise ValueError("Forecast periods must be at least 1.")

    bundle = joblib.load(model_file)
    history = list(bundle["history"])
    last_date = pd.Timestamp(bundle["last_date"])
    origin = pd.Timestamp(bundle["origin_date"])
    estimator = bundle["estimator"]
    model_name = bundle["model_name"]
    records = []

    for offset in range(1, periods + 1):
        forecast_date = last_date + pd.Timedelta(days=offset)
        feature_values = _features_for_date(forecast_date, history, origin)
        if estimator is None:
            prediction = history[-1]
        else:
            row = pd.DataFrame([feature_values], columns=FEATURE_COLUMNS)
            prediction = float(estimator.predict(row)[0])
        # Sales cannot be negative; clip model extrapolations at the valid boundary.
        prediction = max(0.0, float(prediction))
        records.append(
            {
                "date": forecast_date,
                "forecast_sales": prediction,
                "forecast_type": "genuine_future_forecast",
                "model": model_name,
            }
        )
        history.append(prediction)

    forecasts = pd.DataFrame(records)
    destination = Path(output_path) if output_path else PROJECT_ROOT / "reports" / "future_forecast.csv"
    destination.parent.mkdir(parents=True, exist_ok=True)
    forecasts.to_csv(destination, index=False, date_format="%Y-%m-%d")
    print(f"\nGenerated {periods} recursive daily future forecasts with {model_name}.")
    print(f"Saved genuine future forecasts: {destination}")
    return forecasts


def main():
    parser = argparse.ArgumentParser(description="Forecast future sales from the saved model.")
    parser.add_argument("--periods", type=int, default=30, help="Number of future days (default: 30).")
    parser.add_argument(
        "--model",
        default=None,
        help="Optional model bundle path (default: models/sales_forecasting_model.joblib).",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Optional output CSV path (default: reports/future_forecast.csv).",
    )
    args = parser.parse_args()
    forecast_future(args.model, args.periods, args.output)


if __name__ == "__main__":
    main()
