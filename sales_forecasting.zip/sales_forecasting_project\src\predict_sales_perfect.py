"""Generate future daily forecasts using the perfected model."""

import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from src.data_preprocessing import PROJECT_ROOT


def _rebuild_feature_row(target_date, prior_sales, origin_date):
    """Build a single feature row matching the training feature pipeline.
    
    This must produce exactly the same columns as train_model_perfect._build_rich_features.
    `prior_sales` is a list of past daily sales values (oldest first).
    """
    n = len(prior_sales)
    features = {}

    # --- Calendar features ---
    features["day_of_week"] = target_date.dayofweek
    features["day_of_month"] = target_date.day
    features["month"] = target_date.month
    features["quarter"] = target_date.quarter
    features["year"] = target_date.year
    features["week_of_year"] = int(target_date.isocalendar()[1])
    features["is_weekend"] = int(target_date.dayofweek >= 5)
    features["is_month_start"] = int(target_date.is_month_start)
    features["is_month_end"] = int(target_date.is_month_end)
    features["elapsed_days"] = (target_date - origin_date).days

    # Cyclical encoding
    features["dow_sin"] = np.sin(2 * np.pi * features["day_of_week"] / 7)
    features["dow_cos"] = np.cos(2 * np.pi * features["day_of_week"] / 7)
    features["month_sin"] = np.sin(2 * np.pi * features["month"] / 12)
    features["month_cos"] = np.cos(2 * np.pi * features["month"] / 12)
    features["dom_sin"] = np.sin(2 * np.pi * features["day_of_month"] / 31)
    features["dom_cos"] = np.cos(2 * np.pi * features["day_of_month"] / 31)
    features["woy_sin"] = np.sin(2 * np.pi * features["week_of_year"] / 53)
    features["woy_cos"] = np.cos(2 * np.pi * features["week_of_year"] / 53)

    # --- Raw lag features ---
    for lag in [1, 2, 3, 7, 14, 21, 28]:
        features[f"lag_{lag}"] = float(prior_sales[-lag]) if n >= lag else 0.0

    # --- Rolling statistics ---
    arr = np.array(prior_sales)
    for window in [3, 7, 14, 21, 28, 56]:
        if n >= window:
            w = arr[-window:]
            features[f"rmean_{window}"] = float(np.mean(w))
            features[f"rmedian_{window}"] = float(np.median(w))
            if window >= 7:
                features[f"rstd_{window}"] = float(np.std(w))
                features[f"rmin_{window}"] = float(np.min(w))
                features[f"rmax_{window}"] = float(np.max(w))
        else:
            features[f"rmean_{window}"] = float(np.mean(arr)) if n > 0 else 0.0
            features[f"rmedian_{window}"] = float(np.median(arr)) if n > 0 else 0.0
            if window >= 7:
                features[f"rstd_{window}"] = float(np.std(arr)) if n > 1 else 0.0
                features[f"rmin_{window}"] = float(np.min(arr)) if n > 0 else 0.0
                features[f"rmax_{window}"] = float(np.max(arr)) if n > 0 else 0.0

    # --- Percentile features ---
    for window in [14, 28]:
        if n >= window:
            w = arr[-window:]
            features[f"rq25_{window}"] = float(np.percentile(w, 25))
            features[f"rq75_{window}"] = float(np.percentile(w, 75))
            features[f"riqr_{window}"] = features[f"rq75_{window}"] - features[f"rq25_{window}"]
        else:
            features[f"rq25_{window}"] = float(np.percentile(arr, 25)) if n > 0 else 0.0
            features[f"rq75_{window}"] = float(np.percentile(arr, 75)) if n > 0 else 0.0
            features[f"riqr_{window}"] = features[f"rq75_{window}"] - features[f"rq25_{window}"]

    # --- Multi-scale trend features ---
    features["trend_3v14"] = features["rmean_3"] - features["rmean_14"]
    features["trend_7v28"] = features["rmean_7"] - features["rmean_28"]
    features["trend_14v56"] = features["rmean_14"] - features["rmean_56"]
    features["ratio_3v14"] = features["rmean_3"] / (features["rmean_14"] + 1)
    features["ratio_7v28"] = features["rmean_7"] / (features["rmean_28"] + 1)

    # --- Expanding features ---
    features["expanding_mean"] = float(np.mean(arr))
    features["expanding_std"] = float(np.std(arr)) if n > 1 else 0.0
    features["dev_from_mean_7"] = features["rmean_7"] - features["expanding_mean"]
    features["dev_from_mean_28"] = features["rmean_28"] - features["expanding_mean"]

    # --- Same-day-of-week averaged ---
    same_dow_vals = []
    for w in [1, 2, 3, 4]:
        idx = 7 * w
        if n >= idx:
            same_dow_vals.append(float(prior_sales[-idx]))
    features["same_dow_avg_4w"] = float(np.mean(same_dow_vals)) if same_dow_vals else features["rmean_7"]
    features["same_dow_std_4w"] = float(np.std(same_dow_vals)) if len(same_dow_vals) > 1 else 0.0

    # --- Momentum features ---
    features["momentum_1d"] = features["lag_1"] - features["lag_2"]
    features["momentum_7d"] = features["lag_1"] - features["lag_7"]
    features["momentum_14d"] = features["lag_1"] - features["lag_14"]

    return features


def forecast_future_perfect(model_path=None, periods=30, output_path=None):
    """Generate future forecasts using the perfected model."""
    model_file = (
        Path(model_path)
        if model_path
        else PROJECT_ROOT / "models" / "sales_forecasting_model_perfect.joblib"
    )
    if not model_file.is_file():
        raise FileNotFoundError(
            f"Model not found: {model_file}. Run the perfect training first."
        )
    if periods < 1:
        raise ValueError("Forecast periods must be at least 1.")

    print(f"\n{'=' * 70}")
    print(f"GENERATING {periods}-DAY FORECAST (Perfect Model)")
    print(f"{'=' * 70}")

    bundle = joblib.load(model_file)
    history = list(bundle["history"])
    last_date = pd.Timestamp(bundle["last_date"])
    origin = pd.Timestamp(bundle["origin_date"])
    model_info = bundle["model_info"]
    model_name = bundle["model_name"]
    scaler = bundle["scaler"]
    feature_columns = bundle["feature_columns"]

    print(f"Model: {model_name}")
    print(f"Last training date: {last_date.date()}")
    print(f"Forecast: {(last_date + pd.Timedelta(days=1)).date()} -> "
          f"{(last_date + pd.Timedelta(days=periods)).date()}")

    records = []
    for offset in range(1, periods + 1):
        forecast_date = last_date + pd.Timedelta(days=offset)
        feat = _rebuild_feature_row(forecast_date, history, origin)

        # Align to the expected column order
        row_raw = pd.DataFrame([feat])[feature_columns]
        row_scaled = pd.DataFrame(
            scaler.transform(row_raw), columns=feature_columns
        )

        model_type = model_info["type"]

        if model_type == "baseline":
            prediction = feat[model_info["baseline_feature"]]
        elif model_type == "single":
            est = model_info["estimator"]
            pred = float(est.predict(row_scaled)[0])
            if model_info.get("use_log"):
                pred = np.expm1(pred)
            prediction = pred
        elif model_type == "voting":
            pred = float(model_info["estimator"].predict(row_scaled)[0])
            if model_info.get("use_log"):
                pred = np.expm1(pred)
            prediction = pred
        elif model_type == "hybrid":
            # ML prediction
            ml_pred = float(model_info["ml_estimator"].predict(row_scaled)[0])
            if model_info.get("use_log"):
                ml_pred = np.expm1(ml_pred)
            # Rolling mean from raw features
            rolling_pred = feat["rmean_7"]
            alpha = model_info["alpha"]
            prediction = alpha * ml_pred + (1 - alpha) * rolling_pred
        else:
            prediction = feat["rmean_7"]  # fallback

        prediction = max(0.0, float(prediction))
        records.append({
            "date": forecast_date,
            "forecast_sales": prediction,
            "forecast_type": "genuine_future_forecast",
            "model": model_name,
        })
        history.append(prediction)

        if offset % 10 == 0 or offset == periods:
            print(f"  > Generated {offset}/{periods} forecasts...")

    forecasts = pd.DataFrame(records)
    destination = (
        Path(output_path)
        if output_path
        else PROJECT_ROOT / "reports" / "future_forecast_perfect.csv"
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    forecasts.to_csv(destination, index=False, date_format="%Y-%m-%d")

    avg = forecasts["forecast_sales"].mean()
    mn = forecasts["forecast_sales"].min()
    mx = forecasts["forecast_sales"].max()
    total = forecasts["forecast_sales"].sum()

    print(f"\n{'=' * 70}")
    print("FORECAST SUMMARY")
    print(f"{'=' * 70}")
    print(f"Average daily sales: {avg:>12,.2f}")
    print(f"Min daily sales:     {mn:>12,.2f}")
    print(f"Max daily sales:     {mx:>12,.2f}")
    print(f"Total ({periods} days):     {total:>12,.2f}")
    print(f"\n[OK] Saved forecast: {destination.relative_to(PROJECT_ROOT) if destination.is_relative_to(PROJECT_ROOT) else destination}")

    return forecasts


def main():
    parser = argparse.ArgumentParser(
        description="Forecast future sales using the perfect model."
    )
    parser.add_argument("--periods", type=int, default=30,
                        help="Number of future days (default: 30).")
    parser.add_argument("--model", default=None, help="Model bundle path.")
    parser.add_argument("--output", default=None, help="Output CSV path.")
    args = parser.parse_args()
    forecast_future_perfect(args.model, args.periods, args.output)


if __name__ == "__main__":
    main()
