"""Interactive sales forecasting application built on the project pipeline."""

from pathlib import Path

import pandas as pd
import streamlit as st

from src.data_preprocessing import (
    PROJECT_ROOT,
    find_dataset,
    load_and_prepare_data,
    save_cleaned_data,
)
from src.predict_sales import forecast_future
from src.predict_sales_enhanced import forecast_future_enhanced
from src.predict_sales_perfect import forecast_future_perfect
from src.train_model import train_and_evaluate
from src.train_model_enhanced import train_and_evaluate_enhanced
from src.train_model_perfect import train_and_evaluate_perfect


st.set_page_config(page_title="Sales Forecasting App", layout="wide")

# Hide the Streamlit Deploy button and header clutter
st.markdown(
    """
    <style>
    /* Hide Deploy button */
    .stAppDeployButton,
    [data-testid="stAppDeployButton"],
    [data-testid="stDeployButton"],
    .stDeployButton,
    button[data-testid="stBaseButton-header"] {
        display: none !important;
        visibility: hidden !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("Sales Forecasting Application")
st.caption("Upload a retail sales CSV, choose a model architecture, and generate future daily forecasts.")


DATA_DIR = PROJECT_ROOT / "data"


def _find_available_datasets():
    """Return a list of CSV files available in data/ and project root."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    candidates = sorted(DATA_DIR.glob("*.csv"))
    if not candidates:
        candidates = sorted(
            p for p in PROJECT_ROOT.glob("*.csv")
            if p.name.lower() != "cleaned_sales.csv"
        )
    return candidates


def _resolve_dataset(uploaded_file, selected_existing):
    """Resolve the dataset path from upload or sidebar selection."""
    if uploaded_file is not None:
        destination = DATA_DIR / uploaded_file.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(uploaded_file.getvalue())
        return destination

    if selected_existing is not None:
        return selected_existing

    return None


with st.sidebar:
    st.header("Configuration")
    uploaded_file = st.file_uploader("Upload sales CSV", type=["csv"])

    # Show existing datasets for selection
    existing_datasets = _find_available_datasets()
    selected_existing = None
    if uploaded_file is None and existing_datasets:
        if len(existing_datasets) == 1:
            selected_existing = existing_datasets[0]
        else:
            selected_existing = st.selectbox(
                "Select dataset",
                options=existing_datasets,
                format_func=lambda p: p.name,
            )

    dataset_path = _resolve_dataset(uploaded_file, selected_existing)
    if dataset_path is not None:
        st.success(f"Using dataset: {dataset_path.name}")
    else:
        st.info("No dataset found. Upload a CSV to begin.")

    model_engine = st.selectbox(
        "Forecasting Engine",
        options=[
            "Perfect (Hybrid Ensemble) - Recommended",
            "Enhanced (Feature-Rich)",
            "Standard (Baseline)",
        ],
        index=0,
    )

    sample_cols = []
    if dataset_path is not None:
        try:
            sample_df = pd.read_csv(dataset_path, nrows=2)
            sample_cols = list(sample_df.columns)
        except Exception:
            sample_cols = []

    if sample_cols:
        detected_date_idx = 0
        for i, c in enumerate(sample_cols):
            if any(k in c.lower() for k in ("date", "time", "day", "timestamp")):
                detected_date_idx = i + 1
                break
        date_selection = st.selectbox(
            "Date column",
            options=["Auto-detect"] + sample_cols,
            index=detected_date_idx,
            help="Select the column containing transaction dates.",
        )
        date_column = "" if date_selection == "Auto-detect" else date_selection

        detected_sales_idx = 0
        for i, c in enumerate(sample_cols):
            if any(k in c.lower() for k in ("total", "sales", "revenue", "amount")):
                detected_sales_idx = i + 1
                break
        sales_selection = st.selectbox(
            "Sales column",
            options=["Auto-detect"] + sample_cols,
            index=detected_sales_idx,
            help="Select the column containing sales amounts (or keep Auto-detect for quantity x price).",
        )
        sales_column = "" if sales_selection == "Auto-detect" else sales_selection
    else:
        date_column = st.text_input("Date column", placeholder="Auto-detect")
        sales_column = st.text_input("Sales column", placeholder="Auto-detect")

    forecast_periods = st.slider("Future forecast days", min_value=7, max_value=180, value=30)

    run_button = st.button("Run forecast", type="primary")


if dataset_path is None:
    st.warning("Add a CSV in the project data folder or upload one above to start.")
    st.stop()

sample = pd.read_csv(dataset_path)
with st.expander("Uploaded data preview", expanded=False):
    st.dataframe(sample.head(10), use_container_width=True)

if run_button:
    with st.spinner(f"Preparing data, training {model_engine}, and forecasting sales..."):
        try:
            clean_rows, daily_sales, metadata = load_and_prepare_data(
                dataset_path,
                date_column=date_column.strip() or None,
                sales_column=sales_column.strip() or None,
            )
            clean_path = save_cleaned_data(daily_sales)

            if "Perfect" in model_engine:
                training = train_and_evaluate_perfect(daily_sales)
                forecast = forecast_future_perfect(training["model_path"], periods=forecast_periods)
                forecast_file = PROJECT_ROOT / "reports" / "future_forecast_perfect.csv"
            elif "Enhanced" in model_engine:
                training = train_and_evaluate_enhanced(daily_sales)
                forecast = forecast_future_enhanced(training["model_path"], periods=forecast_periods)
                forecast_file = PROJECT_ROOT / "reports" / "future_forecast_enhanced.csv"
            else:
                training = train_and_evaluate(daily_sales)
                forecast = forecast_future(training["model_path"], periods=forecast_periods)
                forecast_file = PROJECT_ROOT / "reports" / "future_forecast.csv"

            st.success("Workflow complete!")

            col1, col2, col3, col4 = st.columns(4)
            col1.metric("Rows Cleaned", f"{metadata['clean_rows']:,}")
            col2.metric("Best Model", training["best_model_name"])
            best_row = training["comparison"].iloc[0]
            col3.metric("Test MAE", f"{best_row['MAE']:,.0f}")
            col4.metric("Test R2", f"{best_row['R2']:+.4f}")

            st.subheader("Model Performance Comparison")
            st.dataframe(training["comparison"], use_container_width=True)

            # Plots
            col_chart1, col_chart2 = st.columns(2)
            comp_chart = PROJECT_ROOT / "graphs" / "model_comparison_chart.png"
            act_pred_chart = PROJECT_ROOT / "graphs" / "actual_vs_predicted.png"

            with col_chart1:
                if act_pred_chart.exists():
                    st.image(str(act_pred_chart), caption="Actual vs Predicted (Test Period)", use_container_width=True)
            with col_chart2:
                if comp_chart.exists():
                    st.image(str(comp_chart), caption="Model Comparison", use_container_width=True)

            st.subheader("Historical Daily Sales & Forecast")
            history_df = pd.DataFrame({"date": pd.to_datetime(daily_sales.index), "sales": daily_sales.values})
            forecast_plot = forecast.copy()
            forecast_plot["date"] = pd.to_datetime(forecast_plot["date"])

            combined_chart = pd.concat([
                history_df.assign(series="Historical Actual"),
                forecast_plot[["date", "forecast_sales"]].rename(columns={"forecast_sales": "sales"}).assign(series="Future Forecast")
            ], ignore_index=True)

            st.line_chart(
                data=combined_chart.tail(120),
                x="date",
                y="sales",
                color="series",
                use_container_width=True
            )

            st.subheader("Future Forecast Table")
            st.dataframe(forecast, use_container_width=True)

            # Direct CSV download button
            forecast_csv_bytes = forecast.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="📥 Download Future Forecast (CSV)",
                data=forecast_csv_bytes,
                file_name=f"future_forecast_{model_engine.split()[0].lower()}.csv",
                mime="text/csv",
                type="primary",
            )

            st.subheader("📋 Operational Summary")
            col_sum1, col_sum2 = st.columns(2)
            with col_sum1:
                st.markdown(f"**📁 Input File:** `{dataset_path.name}`")
                st.markdown(f"**📅 Date Column:** `{metadata['date_column']}`")
                st.markdown(f"**💰 Sales Column:** `{metadata['sales_column']}`")
                if metadata.get('derived_sales'):
                    st.info("Sales derived from quantity × price")
            with col_sum2:
                st.markdown(f"**🧹 Duplicate Rows Removed:** `{metadata['duplicate_rows_removed']:,}`")
                st.markdown(f"**⚠️ Invalid Rows Removed:** `{metadata['invalid_rows_removed']:,}`")
                st.markdown(f"**🤖 Best Model Bundle:** `{Path(training['model_path']).name}`")
                st.markdown(f"**📄 Forecast Report:** `{Path(forecast_file).name}`")
        except Exception as exc:  # pragma: no cover - UI safety catch
            st.error(f"The forecast workflow failed: {exc}")

else:
    st.info("Select options on the sidebar and click 'Run forecast' to train the model on your chosen dataset.")

    # Show pre-trained enterprise benchmarks
    batch_report_path = PROJECT_ROOT / "reports" / "batch_training_report.csv"
    if batch_report_path.exists():
        st.divider()
        st.subheader("🏆 Pre-Trained Enterprise Benchmark (534,000+ Transactions)")
        st.caption("Summary of models trained across 6 real-world enterprise retail sales datasets:")
        try:
            report_df = pd.read_csv(batch_report_path)
            st.dataframe(report_df, use_container_width=True)
        except Exception:
            pass

    # Quick preview if this dataset already has a pre-computed forecast
    slug = dataset_path.stem
    existing_forecast_path = PROJECT_ROOT / "reports" / f"forecast_{slug}.csv"
    if existing_forecast_path.exists():
        st.subheader(f"📊 Latest Saved Forecast for {dataset_path.name}")
        prev_df = pd.read_csv(existing_forecast_path)
        st.dataframe(prev_df.head(10), use_container_width=True)
