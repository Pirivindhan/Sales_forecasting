"""Load, validate, and prepare retail sales data for daily forecasting."""

from pathlib import Path
import re

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
REPORTS_DIR = PROJECT_ROOT / "reports"

DATE_ALIASES = (
    "date",
    "datetime",
    "timestamp",
    "order_date",
    "orderdate",
    "order_datetime",
    "invoice_date",
    "invoicedate",
    "transaction_date",
    "transactiondate",
    "transaction_datetime",
    "trans_date",
    "transdate",
    "sale_date",
    "saledate",
    "sales_date",
    "salesdate",
    "purchase_date",
    "purchasedate",
    "created_at",
    "createdat",
    "bill_date",
    "posting_date",
    "time",
    "day",
)
SALES_ALIASES = (
    "sales",
    "sales_amount",
    "salesamount",
    "sale_amount",
    "saleamount",
    "total_sales",
    "totalsales",
    "net_sales",
    "netsales",
    "gross_sales",
    "grosssales",
    "revenue",
    "total_revenue",
    "totalrevenue",
    "amount",
    "total_amount",
    "totalamount",
    "order_amount",
    "orderamount",
    "transaction_amount",
    "transactionamount",
    "line_total",
    "linetotal",
    "extended_price",
    "item_total",
    "itemtotal",
    "total",
    "grand_total",
    "grandtotal",
    "weekly_sales",
    "weeklysales",
)
QUANTITY_ALIASES = ("quantity", "qty", "units", "quantity_sold", "units_sold", "units_order", "count")
PRICE_ALIASES = ("price", "unit_price", "unitprice", "selling_price", "sellingprice", "unit_selling_price", "item_price", "itemprice")


def _standardize_column_name(name):
    """Convert headers such as 'Order Date', 'SaleDate', or 'order-date' to 'order_date'."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(name).strip())
    normalized = re.sub(r"[^a-zA-Z0-9]+", "_", s.lower())
    return normalized.strip("_")


def find_dataset(csv_path=None):
    """Find one input CSV, preferring data/ and supporting the supplied root CSV."""
    if csv_path is not None:
        path = Path(csv_path)
        if not path.is_absolute():
            path = PROJECT_ROOT / path
        if not path.is_file() or path.suffix.lower() != ".csv":
            raise FileNotFoundError(f"Dataset CSV was not found: {path}")
        return path

    candidates = sorted(DATA_DIR.glob("*.csv"))
    if not candidates:
        # The provided workspace may have a source CSV at its root.
        candidates = sorted(
            path for path in PROJECT_ROOT.glob("*.csv")
            if path.name.lower() != "cleaned_sales.csv"
        )
    if not candidates:
        raise FileNotFoundError(
            "No dataset CSV was found. Put your retail sales CSV in the data folder "
            "and run python main.py. Required columns: a date column (for example "
            "'Order Date') and a numeric 'Sales' column. A file with 'quantity' "
            "and 'price' is also supported; sales will be derived as quantity x price."
        )
    return candidates[0]


def _read_csv(path):
    """Read common Windows CSV encodings without suppressing read errors."""
    try:
        return pd.read_csv(path, encoding="utf-8-sig")
    except UnicodeDecodeError:
        print("The CSV is not UTF-8 encoded; retrying with Windows-1252.")
        return pd.read_csv(path, encoding="cp1252")


def _parse_dates(values):
    """Parse dates and handle day-first datasets when their values make that clear."""
    text = values.astype("string").str.strip()
    day_first = text.str.extract(r"^(\d{1,2})[/-]")[0]
    use_day_first = pd.to_numeric(day_first, errors="coerce").gt(12).any()
    return pd.to_datetime(text, errors="coerce", dayfirst=bool(use_day_first))


def _parse_numeric(values):
    """Parse numeric values with common currency symbols and thousands separators."""
    text = values.astype("string").str.strip()
    accounting_negative = text.str.match(r"^\(.*\)$", na=False)
    text = text.str.replace(r"^\((.*)\)$", r"\1", regex=True)
    text = text.str.replace(r"[$£€¥₹,\s]", "", regex=True)
    numbers = pd.to_numeric(text, errors="coerce")
    numbers.loc[accounting_negative] = -numbers.loc[accounting_negative].abs()
    return numbers


def _select_column(columns, requested, aliases, description):
    if requested is not None and str(requested).strip():
        req_norm = _standardize_column_name(requested)
        if req_norm in columns:
            return req_norm
        for c in columns:
            if c.lower() == str(requested).strip().lower():
                return c
        available = ", ".join(columns)
        raise ValueError(
            f"The requested {description} column '{requested}' was not found. "
            f"Available columns: {available}."
        )

    # 1. Exact alias match
    for alias in aliases:
        if alias in columns:
            return alias

    # 2. Fuzzy substring match
    if description == "date":
        for c in columns:
            if any(k in c for k in ("date", "time", "day", "timestamp")):
                return c
    elif description == "sales":
        for c in columns:
            if any(k in c for k in ("sales", "revenue", "amount", "total")):
                return c

    return None


def load_and_prepare_data(csv_path, date_column=None, sales_column=None):
    """Clean a CSV and return source rows, a continuous daily series, and metadata."""
    csv_path = Path(csv_path)
    raw = _read_csv(csv_path)
    if raw.empty:
        raise ValueError(f"The dataset is empty: {csv_path}")

    raw.columns = [_standardize_column_name(column) for column in raw.columns]
    if len(set(raw.columns)) != len(raw.columns):
        raise ValueError("Two or more CSV columns have the same name after standardization.")

    date_column = _select_column(raw.columns, date_column, DATE_ALIASES, "date")
    sales_column = _select_column(raw.columns, sales_column, SALES_ALIASES, "sales")
    derived_sales = False
    if date_column is None:
        raise ValueError(
            f"Could not identify a date column from columns: {', '.join(raw.columns)}. "
            "Please specify the date column name or add one named 'Date' or 'Order Date'."
        )
    if sales_column is None:
        quantity_column = _select_column(
            raw.columns, None, QUANTITY_ALIASES, "quantity"
        )
        price_column = _select_column(raw.columns, None, PRICE_ALIASES, "price")
        if quantity_column is not None and price_column is not None:
            quantity = _parse_numeric(raw[quantity_column])
            price = _parse_numeric(raw[price_column])
            raw["sales"] = quantity * price
            raw.loc[quantity.lt(0) | price.lt(0), "sales"] = np.nan
            sales_column = "sales"
            derived_sales = True
            print("No direct Sales column found; deriving sales as quantity x price.")
        else:
            raise ValueError(
                f"Could not identify sales values from columns: {', '.join(raw.columns)}. "
                "Add a numeric 'Sales' or 'Total' column, or provide both 'quantity' and 'price' columns."
            )

    original_rows = len(raw)
    duplicate_count = int(raw.duplicated().sum())
    if duplicate_count:
        print(f"Exact duplicate rows found: {duplicate_count}; removing them.")
        raw = raw.drop_duplicates().copy()

    raw["date"] = _parse_dates(raw[date_column])
    if not derived_sales:
        raw["sales"] = _parse_numeric(raw[sales_column])

    invalid_dates = int(raw["date"].isna().sum())
    invalid_sales = int((raw["sales"].isna() | ~np.isfinite(raw["sales"]) | raw["sales"].lt(0)).sum())
    missing_dates = int(raw[date_column].isna().sum())
    missing_sales = int(raw[sales_column].isna().sum())
    invalid = raw["date"].isna() | raw["sales"].isna() | ~np.isfinite(raw["sales"]) | raw["sales"].lt(0)
    removed_invalid = int(invalid.sum())
    if removed_invalid:
        print(
            "Rows removed for invalid values: "
            f"{removed_invalid} (unparseable/missing dates: {invalid_dates}; "
            f"missing or non-numeric/non-finite/negative sales: {invalid_sales})."
        )
    if missing_dates or missing_sales:
        print(
            f"Missing values before cleaning: date={missing_dates}, "
            f"sales={missing_sales}."
        )

    clean = raw.loc[~invalid].copy()
    if clean.empty:
        raise ValueError("No valid rows remain after checking dates and sales values.")
    if removed_invalid + duplicate_count > original_rows * 0.25:
        print(
            "WARNING: More than 25% of the input rows were removed as invalid or "
            "duplicate. Review the source data before relying on the forecasts."
        )

    category_column = "category" if "category" in clean.columns else None
    clean = clean.sort_values("date").reset_index(drop=True)
    daily = clean.groupby("date", as_index=True)["sales"].sum().sort_index()
    # Ensure standard float64 dtype to avoid pandas nullable-type reindex bugs
    daily = daily.astype("float64")
    observed_days = len(daily)

    if observed_days < 14:
        raise ValueError(
            f"The dataset only contains {observed_days} unique date(s). "
            "Time series forecasting requires at least 14 (recommended 30+) distinct calendar dates."
        )

    complete_dates = pd.date_range(daily.index.min(), daily.index.max(), freq="D")
    daily = daily.reindex(complete_dates, fill_value=0.0)
    daily.index.name = "date"
    daily.name = "sales"

    metadata = {
        "date_column": date_column,
        "sales_column": sales_column,
        "derived_sales": derived_sales,
        "category_column": category_column,
        "original_rows": original_rows,
        "duplicate_rows_removed": duplicate_count,
        "invalid_rows_removed": removed_invalid,
        "clean_rows": len(clean),
        "calendar_days": len(daily),
        "zero_sales_days_added": int(len(daily) - observed_days),
    }
    print(
        f"Loaded {csv_path.name}: {original_rows} source rows, "
        f"{len(clean)} valid rows, {len(daily)} daily periods "
        f"({daily.index.min().date()} to {daily.index.max().date()})."
    )
    return clean, daily, metadata


def save_cleaned_data(daily_series, output_path=None):
    """Save the daily sales series, including calendar days with zero recorded sales."""
    destination = Path(output_path) if output_path else REPORTS_DIR / "cleaned_sales.csv"
    destination.parent.mkdir(parents=True, exist_ok=True)
    daily_series.rename_axis("date").rename("sales").to_csv(destination, date_format="%Y-%m-%d")
    return destination
