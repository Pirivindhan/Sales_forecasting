"""Run the complete sales data preparation, EDA, evaluation, and forecasting workflow."""

import argparse


def main():
    parser = argparse.ArgumentParser(
        description="Prepare a sales CSV, evaluate forecasting models, and forecast future sales."
    )
    parser.add_argument(
        "--dataset",
        help="Input CSV path (default: discover one in data/ or the project root).",
    )
    parser.add_argument(
        "--date-column",
        help="Date column name when it is not recognized automatically.",
    )
    parser.add_argument(
        "--sales-column",
        help="Sales amount column name when it is not recognized automatically.",
    )
    args = parser.parse_args()

    try:
        from src.data_preprocessing import (
            find_dataset,
            load_and_prepare_data,
            save_cleaned_data,
        )
        from src.exploratory_analysis import generate_eda_graphs
        from src.predict_sales import forecast_future
        from src.train_model import train_and_evaluate
    except ImportError as exc:
        print(
            f"Could not import a required package or project module: {exc}\n"
            "Activate your virtual environment and run: "
            "python -m pip install -r requirements.txt"
        )
        raise SystemExit(1) from exc

    try:
        dataset = find_dataset(args.dataset)
        print(f"Using dataset: {dataset}")
        cleaned_rows, daily_sales, metadata = load_and_prepare_data(
            dataset, date_column=args.date_column, sales_column=args.sales_column
        )
        clean_path = save_cleaned_data(daily_sales)
        print(f"Saved daily cleaned data: {clean_path}")

        generate_eda_graphs(
            daily_sales, cleaned_rows, category_column=metadata["category_column"]
        )
        training = train_and_evaluate(daily_sales)
        forecast = forecast_future(training["model_path"], periods=30)

        print("\nWorkflow completed.")
        print(f"Input dataset: {dataset}")
        print(
            f"Rows removed: {metadata['duplicate_rows_removed']} exact duplicates and "
            f"{metadata['invalid_rows_removed']} invalid rows."
        )
        if metadata["derived_sales"]:
            print("Sales values were derived from quantity x price.")
        print(f"Cleaned daily data: {clean_path}")
        print(f"Model comparison: {training['comparison_path']}")
        print(f"Saved model and metadata: {training['model_path']}")
        print(f"Future forecast: reports/future_forecast.csv ({len(forecast)} days)")
        print("Graphs: graphs/ (including actual_vs_predicted.png for the test period)")
        print("Test-set predictions are separate from the future forecasts.")
    except (FileNotFoundError, ValueError, OSError) as exc:
        print(f"Sales forecasting could not be completed: {exc}")
        raise SystemExit(1) from exc
    except ImportError as exc:
        print(
            f"A required dependency could not be imported: {exc}\n"
            "Install project dependencies with: python -m pip install -r requirements.txt"
        )
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
